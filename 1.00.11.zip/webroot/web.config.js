export default {
    env: 'prod', // 调试阶段请改为dev，发布阶段请改为prod
}