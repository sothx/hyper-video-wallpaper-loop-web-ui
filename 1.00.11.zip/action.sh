#!/system/bin/sh
am start -n io.github.a13e300.ksuwebui/io.github.a13e300.ksuwebui.WebUIActivity --es id "hyper-video-wallpaper-loop-web-ui"
